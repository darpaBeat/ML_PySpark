# Machine learning with Spark

Code used for the Speaker's corner session on 10.10.19

To run a stage of the pipeline:

```bash
python3 <stage>.py run
```
